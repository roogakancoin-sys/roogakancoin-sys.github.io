# RooGaKan — Coming Soon

Single-file page used for GitHub Pages.

- Edit `index.html` to change links or image
- To use a custom domain on GitHub Pages, add a `CNAME` file (root of repo) containing only your domain (e.g., `example.com`).

